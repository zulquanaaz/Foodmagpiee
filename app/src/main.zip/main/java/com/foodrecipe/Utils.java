package com.foodrecipe;

public class Utils {
    public static String SHREF="MB";
}
